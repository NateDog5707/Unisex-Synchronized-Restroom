#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sys/time.h>
#include <string>
#include <vector>
#include <unistd.h>
#include <pthread.h>
#include "types_p2.h"
#include "p2_threads.h"
#include "utils.h"

pthread_cond_t  cond  = PTHREAD_COND_INITIALIZER;
pthread_cond_t  cond_q  = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  cond_r  = PTHREAD_COND_INITIALIZER;
struct timeval t_global_start;




int main(int argc, char** argv)
{
	srand(time(NULL));
	// This is to set the global start time
	gettimeofday(&t_global_start, NULL);

	int num_people;

	pthread_t       queuetid = 0;
	pthread_t       restroomtid = 0;
	int             status = 0;
	int             work = 0;

	Restroom restroom = Restroom();

	//printf("Jocelyn now has a million dollars!\nWOW!\nNew Balance: $1,000,000.00\n");
	// Check the argument and print error message if the argument is wrong
	if(argc == 2 && (atoi(argv[1]) > 0))
	{
		num_people = atoi(argv[1]);
	}
	else
	{
		printf("[ERROR] Expecting 1 argument, but got (X).\n");
		printf("[USAGE] %s <number>\n", argv[0]);
		exit(1);
	}




	// Example code for sleep and class usage
	/* Person p1;
	p1.set_order(1);

	usleep(MSEC(200));
	p1.start();


	usleep(MSEC(150));
	p1.complete(); */
	///////////////////////////////////////////


	queue_vars pass_in = queue_vars(&restroom, num_people);

 	

	if(pthread_create(&queuetid, NULL, queuethreadfunc, (void *) &pass_in)) {
		fprintf(stderr, "Error creating thread\n");		
	}

	/* printf("[Main] locking");
	pthread_mutex_lock(&mutex); */

	//usleep(MSEC(10));

 	if(pthread_create(&restroomtid, NULL, restroomthreadfunc, (void *) &pass_in)) {
		fprintf(stderr, "Error creating thread\n");		
	}
	//usleep(MSEC(10));  
	//pthread_cond_signal(&cond_r);

	/* for (int i2 = 0; i2 < num_people*2; i2++){


		 for (int i=0; i<1; i++) {
			printf("Wake up thread after (%d) seconds\n", (1-i));
			usleep(MSEC(500));
		} 

		 {
		//when pthread is waiting, mutex is unlocked? i'll see about that
		Person a = Person();
		pthread_mutex_lock(&mutex);
		printf("mutex is locked\n");
		restroom.add_person(&a);
		printf("added a person");
		pthread_mutex_unlock(&mutex);

		printf("currently unlocked");
		
		usleep(MSEC(1000));
		} 


		/ printf("Wake up thread\n");
		status = pthread_cond_signal(&cond);  
		//signal, queue works until it unlocks.
		/printf("[Main] I WANT TO LOCK\n");
		pthread_mutex_lock(&mutex);
		printf("[Main] ~~ some locked action ~~\n");
		usleep(MSEC(500));
		pthread_mutex_unlock(&mutex);
		printf("[Main] unlocking!!\n");
		usleep(MSEC(500)); 




	}  */

	/* wait for the second thread to finish */
	if(pthread_join(queuetid, NULL)) {
		fprintf(stderr, "Error joining thread\n");	
	}
	printf("[Main] Joining Queue Thread\n");
	if(pthread_join(restroomtid, NULL)) {
		fprintf(stderr, "Error joining thread\n");	
	}
	printf("[Main] Joining Restroom Thread\n");
	



	

	while (restroom.isWaitingEmpty() ==false){
		restroom.remove_first_person_from_queue();
		printf("A");
		//pushes to queue
	}
	Person * r;
	while (/*restroom.get_status() >=0*/false|| !restroom.isRestroomEmpty()){
		restroom.remove_first_person_from_inside();
		printf("B");
		// shoud free
	}


	

	printf("yeah");
	return 0;


}

