#ifndef __TYPES_P2_H
#define __TYPES_P2_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sys/time.h>
#include <string>
#include <vector>
#include <unistd.h>
#include <queue>
#include <deque>

#define EMPTY        -1
#define MENPRESENT   0
#define WOMENPRESENT 1


class Person
{

	int gender; // 0: male 1: female
	std::string str_gender;
	struct timeval t_create;
	struct timeval t_start;
	struct timeval t_end;
	long time_to_stay_ms;


	unsigned long order;
	unsigned long use_order;

public:
	Person();
	Person(int, int);

	void set_gender(int data);
	int get_gender(void);

	void set_order(unsigned long data);
	unsigned long get_order(void);

	void set_use_order(unsigned long data);
	unsigned long get_use_order(void);

	void set_create_time();

	void set_time(long data);
	long get_time(void);
	int ready_to_leave(void); // 1 == ready to leave, 0 = not ready to leave yet

	void start(void);
	void complete(void);

	void print_person(Person * p);
};


// Class for the restroom
// You may need to add more class member variables and functions
class Restroom {
	int status;
	//int num_people;
	std::deque<Person*> list_inside;
	std::queue<Person*> list_waiting;

	// You need to define the data structure to
    // save the information of people using the restroom
	// You can probebly use Standard Template Library (STL) vector

public:
	Restroom(){
		status = EMPTY;
		//num_people = 0;
		this->status = -1;

	}

	// You need to use this function to print the Restroom's status
	void print_status(void);
	int get_status(void);
	void set_status(int);

	int get_next_gender(void);

	int isRestroomEmpty(void);

	int isWaitingEmpty(void);

	int countMenInQueue(void);
	int countWomenInQueue(void);

	// Call by reference
	// This is just an example. You can implement any function you need
	void add_person(Person* p);
	void add_person_to_queue(Person* p);

	void remove_person(Person* p);
	void remove_first_person_from_inside();
	void remove_first_person_from_queue();

	void checkPeopleInside(void);

	void man_wants_to_enter(Person* p);
	void man_wants_to_leave(Person* p);
	void woman_wants_to_enter(Person* p);
	void woman_wants_to_leave(Person* p);

	int get_restroom_num(void);
	int get_waiting_num(void);
};



class queue_vars{
	
	Restroom * restroom;
	int num_in_queue;

	public:
		/* queue_vars(){
			num_in_queue = 0;
		} */
		queue_vars(Restroom* r, int num);
		Restroom * get_restroom();
		int get_num_in_queue();
};






#endif
