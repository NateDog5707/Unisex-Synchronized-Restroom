#include "p2_threads.h"
#include "types_p2.h"
#include "utils.h"

extern pthread_cond_t  cond;
extern pthread_cond_t  cond_r;
extern pthread_mutex_t mutex;
extern struct timeval t_global_start;

std::vector<Person*> men_queue;
std::vector<Person*> women_queue;

int restroomsignal = 1;


void * queuethreadfunc(void *parm)
{
	printf("[Queue] Thread created!\n");
	queue_vars * queue_s = (queue_vars *) parm;
	Restroom * restroom = queue_s->get_restroom();
	int num_people = queue_s->get_num_in_queue();



	Person * man;
	// initialize the queues
	for (int i = 1; i <= num_people;i++){

		man = (Person *) malloc(sizeof(Person));
		man->set_create_time();
		man->set_gender(0);
		man->set_order(i);
		man->set_time(((rand()%7) +3));
		//printf("%ld\n", man->get_time());
		men_queue.push_back(man);


		//repeat for woman
		man = (Person *) malloc(sizeof(Person));
		man->set_create_time();
		man->set_gender(1);
		man->set_order(i);
		man->set_time(((rand()%7) +3));
		//printf("%ld\n", man->get_time());
		women_queue.push_back(man);
 
		
	}




	int status;
	int count = 0;
	int wait_time;
	Person * curr;
	struct timeval now;
	do{
		//printf(" [Queue] Start\n");


		//add a person by (randomizing gender) and (adding to restroom's waiting queue);
		if ((rand()%2 == 0 && (men_queue.size() > 0)) || (women_queue.size()<=0 || women_queue.empty())){
			//man
			//printf("man\n");
			curr = men_queue.back();
			men_queue.pop_back();

			

		}else{
			//woman
			//printf("woman\n");
			curr = women_queue.back();
			women_queue.pop_back();
		}
		curr->set_use_order(count+1);

		//printf(" [Queue] Locks\n");
		status = pthread_mutex_lock(&mutex);
		//restroom->print_status();
		//printf(" [Queue] Successfully locked\n");
		/* printf(" [Queue] Blocked\n");
		status = pthread_cond_wait(&cond, &mutex); */
		/*
		printf(" [Queue] Starts again.\n");
		for (int i=0; i<3; i++) {
			printf(" [Queue] Complete thread after (%d) seconds\n", (3-i));
			usleep(MSEC(1000));
		} */ 

		//work with restroom buffer.
		//printf(" [Queue] ~adding person to queue~\n");
		
		curr->set_create_time();
		restroom->add_person_to_queue(curr);
		//printf(" [Queue] ");

		//printf(" [Queue] Unlocks\n");
		status = pthread_mutex_unlock(&mutex);
		//status = pthread_cond_signal(&cond);
		//printf(" [Queue] Complete\n");
		
		gettimeofday(&now, NULL);
		if (curr->get_gender() ==0){
			printf("[%ld ms][Queue] Send (Man) to the restroom. ", get_elapsed_time(t_global_start, now));

		}
		else{
			printf("[%ld ms][Queue] Send (Woman) to the restroom. ", get_elapsed_time(t_global_start, now));
		}

	


		//randomly wait 1-5 msec to add another person to queue
		wait_time = (rand() % 4) + 1;
			if (!restroom->isWaitingEmpty()){
				printf("(Stay %d ms). Total: %d. Men: %d, Women: %d\n", wait_time, restroom->get_waiting_num(), restroom->countMenInQueue(), restroom->countWomenInQueue());
			}
			else{
				printf("(Stay %d ms). Status is Empty. Total: 0. Men: 0, Women: 0\n", wait_time);
			}
			
			if (count == 0){
			restroomsignal = 0;
		}
			
		usleep(MSEC(wait_time));
		count++;


	} while(!men_queue.empty() || !women_queue.empty());


	if (men_queue.size() > 0){
		printf("men still left in queue DANGER DANGER\n");
		printf("size: %ld", men_queue.size());
	}
	if (women_queue.size() > 0){
		printf("women still left in queue DANGER DANGER\n");
		printf("size: %ld", women_queue.size());
	}

	//thread is over, free the malloc

	/* for (int i =0; i < num_people;i++){
		free(men_queue.at(i));
		free(women_queue.at(i));
	} */

	return parm;
}

void * restroomthreadfunc(void * parm){

	//pthread_cond_wait(&cond_r, &mutex);
	//usleep(MSEC(100));
	

	printf("[Restroom] Thread created!\n");
	struct timeval now;
	queue_vars * queue_s = (queue_vars *) parm;
	Restroom * restroom = queue_s->get_restroom();
	int num_people = queue_s->get_num_in_queue();
	int wait_time;

	int status;
	//queue<Person*>iterator currinside;

	//wait for 

	while (restroomsignal != 0){
		usleep(1);
	}


	//for (int i = 0; i < num_people*2; i++){
	while ((men_queue.size() > 0 || women_queue.size() >0) || !restroom->isWaitingEmpty() || !restroom->isRestroomEmpty()){
		//printf("[Restroom] Start\n");

		//here, check if next in loop is same gender. if so, add!
		//else, resume waiting.

		/* if (restroom->list_waiting.front()->get_gender()== restroom->get_status()){

		} *//* 
		if (restroom->get_next_gender() == restroom->get_status()){
			//add another person while we wait
			

			pthread_mutex_lock(&mutex);

			restroom->remove_first_person_from_queue();

			pthread_mutex_unlock(&mutex);
		} */

		//else{

			//printf("[Restroom] I WANT TO LOCK\n");
			pthread_mutex_lock(&mutex); //waits until something is in queue


			//printf("[Restroom] ~~ removing a person from queue ~~\n");
			restroom->remove_first_person_from_queue();
			//restroom->add person p

					//print somebody enters message 
			if (restroom->get_status() == 0){
				gettimeofday(&now, NULL);
				printf("[%ld ms][Restroom] (Man) goes into the restroom, State is (Men Present). Men: %d, Women: 0\n", get_elapsed_time(t_global_start, now), restroom->get_restroom_num());
			}
			else if (restroom->get_status() == 1){
				gettimeofday(&now, NULL);
				printf("[%ld ms][Restroom] (Woman) goes into the restroom, State is (Women Present). Men: 0, Women: %d\n", get_elapsed_time(t_global_start, now), restroom->get_restroom_num());
			}

			//restroom->print_status();
			//usleep(MSEC(500));
			while (restroom->isWaitingEmpty() == false){
				if (restroom->get_next_gender() == restroom->get_status()){
					
					wait_time = (rand() % 4) + 1;
					usleep(MSEC(wait_time));

					//printf("pushed 1 more\n");
					restroom->remove_first_person_from_queue();
							//print somebody enters message 
					if (restroom->get_status() == 0){
						gettimeofday(&now, NULL);
						printf("[%ld ms][Restroom] (Man) goes into the restroom, State is (Man Present). Men: %d, Women: 0\n", get_elapsed_time(t_global_start, now), restroom->get_restroom_num());
					}
					else if (restroom->get_status() == 1){
						gettimeofday(&now, NULL);
						printf("[%ld ms][Restroom] (Woman) goes into the restroom, State is (Women Present). Men: 0, Women: %d\n", get_elapsed_time(t_global_start, now), restroom->get_restroom_num());
					}

				}
				else{
					break;
				}
			}
			//printf("[Restroom] unlocking!!\n");
			pthread_mutex_unlock(&mutex);

		

			//printf("[Restroom] Complete!!\n");
			//usleep(MSEC(500));
		
		
		//}
		/* 
		printf("check for same gender\n");
		if (!restroom->isWaitingEmpty()){
			while(restroom->get_next_gender() == restroom->get_status()){
				//add another one from queue
				pthread_mutex_lock(&mutex);
				restroom->remove_first_person_from_queue();
				pthread_mutex_unlock(&mutex);
			}
		} 
		printf("done check for same gender\n"); */
		
			while (restroom->get_status() >= 0 ){
				//usleep(MSEC(100));
				//printf("checking people inside : \n");
				restroom->checkPeopleInside();
				//waits
				//usleep(MSEC(1));

				//printf("a");
			} 

	}
	
	//printf("[Restroom] Complete\n");

	return parm;


}
