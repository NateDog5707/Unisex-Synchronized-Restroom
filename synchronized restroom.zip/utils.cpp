#include "utils.h"


long get_elapsed_time(struct timeval& start, struct timeval& end)
{
    //printf("start get_elapsed_time\n");
	long mtime = 0;
    long seconds  = end.tv_sec  - start.tv_sec;
    long useconds = end.tv_usec - start.tv_usec;
    //printf("start.sec: %ld\t end.sec: %ld\n", start.tv_sec, end.tv_sec);
    //printf("seconds: %ld\tuseconds: %ld\n",seconds, useconds);

    mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;

    //printf("=%ld=\n", mtime);
	return mtime;
}



