#include "types_p2.h"
#include "utils.h"

extern struct timeval t_global_start;

void Person::set_gender(int data) { gender = data; }
int Person::get_gender(void)      { return gender; }

void Person::set_order(unsigned long data) { order = data; }
unsigned long Person::get_order(void)      { return order; }

void Person::set_use_order(unsigned long data) { use_order = data; }
unsigned long Person::get_use_order(void)      { return use_order; }


void Person::set_time(long data) { time_to_stay_ms = data; }
long Person::get_time(void) { return time_to_stay_ms; }
int Person::ready_to_leave(void) {
	struct timeval t_curr;
	gettimeofday(&t_curr, NULL);

	if (get_elapsed_time(t_start, t_curr) >= time_to_stay_ms) { 
		//printf("time elapsed: %ld\ttime to stay: %ld\n", get_elapsed_time(t_start,t_curr),time_to_stay_ms);
		return 1; }
	else { return 0; }
}

void Person::set_create_time(){
	gettimeofday(&t_create, NULL);
}


void Person::start(void) {
	gettimeofday(&t_start, NULL);
	//printf("(%lu)th person enters the restroom: \n", use_order);
	//printf(" - (%lu) milliseconds after the creation\n", get_elapsed_time(t_create, t_start));
}

void Person::complete(void) {
	gettimeofday(&t_end, NULL);
	//printf("(%lu)th person comes out of the restroom: \n", use_order);
	//printf(" - (%lu) milliseconds after the creation\n", get_elapsed_time(t_create, t_end));
	//printf(" - (%lu) milliseconds after using the restroom\n", get_elapsed_time(t_start, t_end));
}

void Person::print_person(Person * p){
	printf("--- :) ---\n");
	printf("Person order: %ld\n", this->get_order());
	printf("Gender: %d\n", this->gender);
	printf("TTS: %ld\n", this->get_time());


}


Person::Person() {
	gettimeofday(&t_create, NULL);
}

Person::Person(int gender, int time){
	gettimeofday(&t_create, NULL);
	set_gender(gender);
	set_time(time);
}









// You need to use this function to print the Restroom's status
void Restroom::print_status(void) {
	printf("Print restroom status\n");
	if (this->status == 0){
		printf("Men Present\n");
	}
	else if (this->status==1){
		printf("Women Present\n");
	}
	else{
		printf("Empty\n");
	}
}


//empty = -1, men = 0, women = 1
int Restroom::get_status(void){
	return this->status;
}

void Restroom::set_status(int new_status){
	this->status = new_status;
}


int Restroom::isRestroomEmpty(void){

	if (this->list_inside.size()>0){
		return false;
	}
	return true;
}

int Restroom::isWaitingEmpty(void){

	if (this->list_waiting.size()>0){
		return false;
	}
	return true;
}




//modifiers

// Call by reference
// This is just an example. You can implement any function you need
void Restroom::add_person(Person* p) {

	this->list_inside.push_back(p);
	p->start();
}

void Restroom::add_person_to_queue(Person* p){
	this->list_waiting.push(p);
}


void Restroom::remove_person(Person* p){

	int gap = 0;
	for (int i = 0; i < this->list_inside.size(); i++){
		if (this->list_inside.at(i) == p){
			gap = i;
			break;
		}
	}  
	
	//printf("list_inside.begin + gap = %ld\n", list_inside.at(0+gap)->get_use_order());
	list_inside.erase(list_inside.begin() + gap);

/* 	p->complete();
	free(p);

	if (list_inside.size() == 0){
		this->set_status(-1);
	} */

	if (p->get_gender() ==0){
		man_wants_to_leave(p);
	}
	else{
		woman_wants_to_leave(p);
	}

}

void Restroom::remove_first_person_from_inside(){

	Person *p = list_inside.front();
	list_inside.pop_front();
	free(p);
}

void Restroom::remove_first_person_from_queue(){
	if (list_waiting.size() == 0){
		return;
	}
	Person *p = list_waiting.front();

	if (p->get_gender() == 0 && this->get_status() <= 0){
		man_wants_to_enter(p);
		list_waiting.pop();
		
	}
	else if(p->get_gender() == 1 && (this->get_status() == -1 || this->get_status() == 1)){

		woman_wants_to_enter(p);
		list_waiting.pop();
	}
	//else, mixing up of stuff, cannot
	return;
		
}

void Restroom::man_wants_to_enter(Person* p){
		add_person(p);
		this->set_status(0);
}
void Restroom::woman_wants_to_enter(Person* p){
		add_person(p);
		this->set_status(1);
}


void Restroom::man_wants_to_leave(Person* p){
	p->complete();
	free(p);

	if (list_inside.size() == 0){
		this->set_status(-1);
	}
}
void Restroom::woman_wants_to_leave(Person* p){
	p->complete();
	free(p);

	if (list_inside.size() == 0){
		this->set_status(-1);
	}
}




void Restroom::checkPeopleInside(void){
	Person *p;
	struct timeval now;
	for (int i = 0; i <  this->list_inside.size();i++){
		p = list_inside.at(i);

		//p->print_person(p);
		int gender = p->get_gender();

		if (p->ready_to_leave() == 1){

			remove_person(p);

			//print a message to remove
			gettimeofday(&now, NULL);
			if (gender ==0){
				printf("[%ld ms][Restroom] (Man) left the restroom.", get_elapsed_time(t_global_start, now));
			}
			else{
				printf("[%ld ms][Restroom] (Woman) left the restroom.", get_elapsed_time(t_global_start, now));
			}

			if (this->isRestroomEmpty()){
				printf(" Status is changed, Status is (Empty). Total: 0. Men: 0, Women: 0\n");
			}
			else{
				//printf("\nget_gender: %d\n", p->get_gender());
				if (gender == 0){
					printf(" Status is (Men Present). Men: %d, Women: 0\n", this->get_restroom_num());
				}
				else{
					printf(" Status is (Women Present). Men: 0, Women: %d\n", this->get_restroom_num());
				}
			}

			//printf("REMOVED AN INDIVIDUAL\n");
			i--;
		}
	}
}

int Restroom::get_next_gender(void){
	if (this->list_waiting.front()->get_gender()== 0){
		return 0; // man
	}
	return 1; //woman
}


	int Restroom::get_restroom_num(void){
		return this->list_inside.size();
	}
	int Restroom::get_waiting_num(void){
		return this->list_waiting.size();
	}


int Restroom::countMenInQueue(void){
	Person *p;
	int count = 0;
	for (int i =0 ; i < this->list_waiting.size(); i++){
		if (p->get_gender() ==0){
			count++;
		}
	}
	return count;
}

int Restroom::countWomenInQueue(void){
	Person *p;
	int count = 0;
	for (int i =0 ; i < this->list_waiting.size(); i++){
		if (p->get_gender() ==1){
			count++;
		}
	}
	return count;
}


queue_vars::queue_vars(Restroom * r, int num){
	
		restroom = r;
		num_in_queue = num;
		
}

Restroom* queue_vars::get_restroom(){
		//printf("check for same gender\n");
	return this->restroom;
}


int queue_vars::get_num_in_queue(){
	return this->num_in_queue;
}